<?php

$l10n_ls_mce = array(

	// TinyMCE slider chooser widget
	'MCEAddLayerSlider' => __('Add LayerSlider', 'LayerSlider'),
	'MCEInsertSlider' 	=> __('Insert LayerSlider', 'LayerSlider'),
	'MCEEmbedOptions' 	=> __('Embed Options:', 'LayerSlider'),
	'MCEStartingSlide' 	=> __('Starting Slide:', 'LayerSlider'),
	'MCENoOverride' 	=> __('no override', 'LayerSlider'),
	'MCEInsertButton' 	=> __('Insert into post', 'LayerSlider'),
	'MCENoPreview' 		=> __('No Preview', 'LayerSlider'),
	'MCENoPreviewText' 	=> __('Previews are automatically generated from slide images in sliders.', 'LayerSlider')
);